main函数在main.cpp中，读取test.txt中的测试用例，之后调用lab1.cpp中的函数lab1求解，把答案写入answer.txt中。
请完成lab1.cpp中的函数lab1，已经给出了部分代码，如果你想修改给出的lab1中的代码也可以，但是只能修改lab1.cpp一个文件，不能改动其它任何文件。
最后提交只提交lab1.cpp一个文件。不要在lab1.cpp中调用任何输入输出操作，比如scanf, printf和各种文件操作。