int test2(int a) {
    assert( ~0 == -1);
}