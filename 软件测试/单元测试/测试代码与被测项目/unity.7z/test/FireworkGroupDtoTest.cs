﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Firework;
using Dto;
using System;

namespace Tests
{
    public class FireworkGroupDtoInputs
    {
        public static IEnumerable<Tuple<List<Pair>, List<FireworkType>>> SetPairInputs()
        {
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                null,
                new List<FireworkType> { }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkNormal(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Normal }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkOnlyTrail(), Vector3.zero) },
                new List<FireworkType> { FireworkType.OnlyTrail }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkBrocade(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Brocade }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkCrackle(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Crackle }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkMine(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Mine }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkThreeLayers(), Vector3.zero) },
                new List<FireworkType> { FireworkType.ThreeLayers }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkImage(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Image }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkImage(imageData: new FireworkImage.ImageInfo(0, 0, null)), Vector3.zero) },
                new List<FireworkType> { FireworkType.Image }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkBase(), Vector3.zero) },
                new List<FireworkType> { }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkNormal(), Vector3.zero), new Pair(new FireworkNormal(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Normal, FireworkType.Normal }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkNormal(), Vector3.zero), new Pair(new FireworkNormal(), Vector3.zero), new Pair(new FireworkMine(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Normal, FireworkType.Normal, FireworkType.Mine }
            );
        }

        public static IEnumerable<Tuple<List<Pair>, List<FireworkType>>> GetPairInputs()
        {
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                null,
                new List<FireworkType> { }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkNormal(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Normal }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkOnlyTrail(), Vector3.zero) },
                new List<FireworkType> { FireworkType.OnlyTrail }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkBrocade(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Brocade }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkCrackle(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Crackle }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkMine(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Mine }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkThreeLayers(), Vector3.zero) },
                new List<FireworkType> { FireworkType.ThreeLayers }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkImage(), Vector3.zero) },
                new List<FireworkType> { FireworkType.Image }
            );
            yield return new Tuple<List<Pair>, List<FireworkType>>(
                new List<Pair> { new Pair(new FireworkBase(), Vector3.zero) },
                new List<FireworkType> { }
            );
        }

        public static IEnumerable<Tuple<FireworkGroupDto, List<FireworkType>>> GetFireworkGroupDtoInputs()
        {
            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto
            {
                Tag = 1,
                Model = ModelType.Cake1,
                Audio = null
            };
            fireworkGroupDto.SetPairs(new List<Pair>
            {

            });
            yield return new Tuple<FireworkGroupDto, List<FireworkType>>(
                fireworkGroupDto,
                new List<FireworkType> { }
            );

            fireworkGroupDto = new FireworkGroupDto
            {
                Tag = 1,
                Model = ModelType.Cake1,
                Audio = null
            };
            fireworkGroupDto.SetPairs(new List<Pair>
            {
                new Pair(new FireworkNormal(), Vector3.zero)
            });
            yield return new Tuple<FireworkGroupDto, List<FireworkType>>(
                fireworkGroupDto,
                new List<FireworkType> { FireworkType.Normal }
            );

            fireworkGroupDto = new FireworkGroupDto
            {
                Tag = 1,
                Model = ModelType.Cake1,
                Audio = null
            };
            fireworkGroupDto.SetPairs(new List<Pair>
            {
                new Pair(new FireworkOnlyTrail(), Vector3.zero),
                new Pair(new FireworkBrocade(), Vector3.zero),
            });
            yield return new Tuple<FireworkGroupDto, List<FireworkType>>(
                fireworkGroupDto,
                new List<FireworkType> { FireworkType.OnlyTrail, FireworkType.Brocade }
            );

            fireworkGroupDto = new FireworkGroupDto
            {
                Tag = 1,
                Model = ModelType.Cake1,
                Audio = null
            };
            fireworkGroupDto.SetPairs(new List<Pair>
            {
                new Pair(new FireworkCrackle(), Vector3.zero),
                new Pair(new FireworkMine(), Vector3.zero),
                new Pair(new FireworkThreeLayers(), Vector3.zero),
                new Pair(new FireworkImage(), Vector3.zero),
                new Pair(new FireworkBase(), Vector3.zero),
            });
            yield return new Tuple<FireworkGroupDto, List<FireworkType>>(
                fireworkGroupDto,
                new List<FireworkType> { FireworkType.Crackle, FireworkType.Mine, FireworkType.ThreeLayers, FireworkType.Image }
            );
        }
    }

    public class FireworkGroupDtoTest
    {
        [Test]
        public void SetPairTest([ValueSource(typeof(FireworkGroupDtoInputs), nameof(FireworkGroupDtoInputs.SetPairInputs))] Tuple<List<Pair>, List<FireworkType>> inputs)
        {
            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();
            fireworkGroupDto.SetPairs(inputs.Item1);
            Assert.AreEqual(inputs.Item2.Count, fireworkGroupDto.Fireworks.Count);
            for (int i = 0; i < inputs.Item2.Count; ++i)
            {
                Assert.AreEqual(inputs.Item2[i], fireworkGroupDto.Fireworks[i].Type);
            }
        }

        [Test]
        public void GetPairTest([ValueSource(typeof(FireworkGroupDtoInputs), nameof(FireworkGroupDtoInputs.GetPairInputs))] Tuple<List<Pair>, List<FireworkType>> inputs)
        {
            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();
            fireworkGroupDto.SetPairs(inputs.Item1);
            List<Pair> pairs = fireworkGroupDto.GetPairs();
            Assert.AreEqual(inputs.Item2.Count, pairs.Count);
            for (int i = 0; i < inputs.Item2.Count; ++i)
            {
                Assert.AreEqual(inputs.Item2[i], pairs[i].Firework.Type);
            }
        }

        [Test]
        public void GetFireworkGroupDtoTest([ValueSource(typeof(FireworkGroupDtoInputs), nameof(FireworkGroupDtoInputs.GetFireworkGroupDtoInputs))] Tuple<FireworkGroupDto, List<FireworkType>> inputs)
        {
            FireworkGroupDto fireworkGroupDto = FireworkGroupDtoUtils.GetFireworkGroupDto(FireworkGroupDtoUtils.GetJson(inputs.Item1));
            List<Pair> pairs = fireworkGroupDto.GetPairs();
            Assert.AreEqual(inputs.Item2.Count, pairs.Count);
            for (int i = 0; i < inputs.Item2.Count; ++i)
            {
                Assert.AreEqual(inputs.Item2[i], pairs[i].Firework.Type);
            }
        }

        [Test]
        public void PairTest()
        {
            // Getter/Setter
            Pair pair = new Pair(new FireworkNormal(), Vector3.zero);
            Assert.AreEqual(Vector3.zero, pair.Position);

            Assert.AreEqual(FireworkType.Normal, pair.Firework.Type);
            FireworkNormal fireworkNormal = (FireworkNormal)pair.Firework;
            Assert.AreEqual(fireworkNormal.InitialVelocity, FireworkNormal.defaultInitialVelocity);
            Assert.AreEqual(fireworkNormal.Radius, FireworkNormal.defaultRadius);
            Assert.AreEqual(fireworkNormal.FireworkColor, FireworkNormal.defaultFireworkColor);

            pair.Firework = new FireworkBrocade();
            pair.Position = Vector3.one;
            Assert.AreEqual(Vector3.one, pair.Position);

            Assert.AreEqual(FireworkType.Brocade, pair.Firework.Type);
            FireworkBrocade fireworkBrocade = (FireworkBrocade)pair.Firework;
            Assert.AreEqual(fireworkBrocade.InitialVelocity, FireworkBrocade.defaultInitialVelocity);
            Assert.AreEqual(fireworkBrocade.Radius, FireworkBrocade.defaultRadius);
            Assert.AreEqual(fireworkBrocade.FireworkColor, FireworkBrocade.defaultFireworkColor);
        }

        [Test]
        public void FireworkGroupBaseTest()
        {
            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();

            // Getter/Setter
            fireworkGroupDto.Model = ModelType.Cake1;
            Assert.AreEqual(ModelType.Cake1, fireworkGroupDto.Model);

            fireworkGroupDto.Tag = 123;
            Assert.AreEqual(123, fireworkGroupDto.Tag);

            fireworkGroupDto.Fireworks = new List<FireworkBase>();
            Assert.AreNotEqual(null, fireworkGroupDto.Fireworks);
            Assert.AreEqual(0, fireworkGroupDto.Fireworks.Count);

            List<Pair> fireworkPairs = new List<Pair>
            {
                new Pair(new FireworkNormal(initialVelocity: 1.8f), Vector3.one),
            };
            fireworkGroupDto.SetPairs(fireworkPairs);
            Assert.AreEqual(1, fireworkGroupDto.Fireworks.Count);

            Assert.AreEqual(FireworkType.Normal, fireworkGroupDto.Fireworks[0].Type);
            FireworkNormalDto fireworkNormalDto = (FireworkNormalDto)fireworkGroupDto.Fireworks[0];
            Assert.AreEqual(fireworkNormalDto.X, 1);
            Assert.AreEqual(fireworkNormalDto.Y, 1);
            Assert.AreEqual(fireworkNormalDto.Z, 1);
            Assert.AreEqual(fireworkNormalDto.InitialVelocity, 1.8f);
            Assert.AreEqual(fireworkNormalDto.Radius, FireworkNormal.defaultRadius);
            Assert.AreEqual(fireworkNormalDto.FireworkColor, FireworkNormal.defaultFireworkColor);

            fireworkPairs = fireworkGroupDto.GetPairs();
            Assert.AreEqual(1, fireworkPairs.Count);
            Pair pair = fireworkPairs[0];
            Assert.AreEqual(Vector3.one, pair.Position);

            Assert.AreEqual(FireworkType.Normal, pair.Firework.Type);
            FireworkNormal fireworkNormal = (FireworkNormal)pair.Firework;
            Assert.AreEqual(fireworkNormal.InitialVelocity, 1.8f);
            Assert.AreEqual(fireworkNormal.Radius, FireworkNormal.defaultRadius);
            Assert.AreEqual(fireworkNormal.FireworkColor, FireworkNormal.defaultFireworkColor);
        }

        [Test]
        public void FireworkGroupTestPro()
        {
            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();
            Texture2D testTexture = (Texture2D)Resources.Load("Test/TestRabbit");
            List<Pair> fireworkPairs = new List<Pair>
            {
                new Pair(new FireworkNormal(initialVelocity: 1.8f), Vector3.one),
                new Pair(new FireworkOnlyTrail(), Vector3.zero),
                new Pair(new FireworkBrocade(), Vector3.zero),
                new Pair(new FireworkCrackle(), Vector3.zero),
                new Pair(new FireworkMine(), Vector3.zero),
                new Pair(new FireworkThreeLayers(), Vector3.zero),
                new Pair(new FireworkImage(), Vector3.zero),
                new Pair(new FireworkImage(imageData: ImageCompressionHelper.GetCompressImage(testTexture)), Vector3.zero)
            };

            fireworkGroupDto.SetPairs(fireworkPairs);
            Assert.AreEqual(8, fireworkGroupDto.Fireworks.Count);

            fireworkPairs = fireworkGroupDto.GetPairs();
            Assert.AreEqual(8, fireworkPairs.Count);

            fireworkGroupDto.SetPairs(null);
            Assert.AreEqual(0, fireworkGroupDto.GetPairs().Count);

            fireworkGroupDto = new FireworkGroupDto();
            Assert.AreEqual(null, fireworkGroupDto.GetPairs());

            fireworkGroupDto.Fireworks = new List<FireworkBase>()
            {
                new FireworkBase()
            };
            fireworkPairs = fireworkGroupDto.GetPairs();
            Assert.AreEqual(0, fireworkPairs.Count);
        }

        [Test]
        public void FireworkGroupDtoUtilTest()
        {
            int res = 0;
            try
            {
                FireworkGroupDtoUtils.GetJson(new FireworkGroupDto());
            }
            catch (Exception)
            {
                ++res;
            }
            Assert.AreEqual(1, res);
            res = 0;

            try
            {
                FireworkGroupDtoUtils.GetFireworkGroupDto("");
            }
            catch(Exception)
            {
                ++res;
            }
            Assert.AreEqual(1, res);

            FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();
            List<Pair> fireworkPairs = new List<Pair>
            {
                new Pair(new FireworkNormal(initialVelocity: 1.8f), Vector3.one),
                new Pair(new FireworkOnlyTrail(), Vector3.zero),
                new Pair(new FireworkBrocade(), Vector3.zero),
                new Pair(new FireworkCrackle(), Vector3.zero),
                new Pair(new FireworkMine(), Vector3.zero),
                new Pair(new FireworkThreeLayers(), Vector3.zero),
                new Pair(new FireworkImage(), Vector3.zero),
                new Pair(new FireworkBase(), Vector3.zero)
            };
            fireworkGroupDto.SetPairs(fireworkPairs);
            fireworkGroupDto.Fireworks.Add(new FireworkBase());

            fireworkGroupDto = FireworkGroupDtoUtils.GetFireworkGroupDto(FireworkGroupDtoUtils.GetJson(fireworkGroupDto));
            Assert.AreEqual(FireworkType.Normal, fireworkGroupDto.Fireworks[0].Type);
            FireworkNormalDto fireworkNormalDto = (FireworkNormalDto)fireworkGroupDto.Fireworks[0];
            Assert.AreEqual(fireworkNormalDto.X, 1);
            Assert.AreEqual(fireworkNormalDto.Y, 1);
            Assert.AreEqual(fireworkNormalDto.Z, 1);
            Assert.AreEqual(fireworkNormalDto.InitialVelocity, 1.8f);
            Assert.AreEqual(fireworkNormalDto.Radius, FireworkNormal.defaultRadius);
            Assert.AreEqual(fireworkNormalDto.FireworkColor, FireworkNormal.defaultFireworkColor);
        }

        [Test]
        public void QueryDtoTest()
        {
            QueryDto queryDto = new QueryDto(tag: 1);
            Assert.AreEqual(1, queryDto.Tag);
        }
    }
}


