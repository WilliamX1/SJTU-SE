﻿using Firework;
using UnityEngine;

namespace Dto
{
    public interface IObjectWithPosition
    {
        float X { get; }
        float Y { get; }
        float Z { get; }
    }

    public class FireworkNormalDto : FireworkNormal, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkNormalDto()
        {

        }

        public FireworkNormalDto(Vector3 launchPosition,
            FireworkColorType fireworkColor,
            float initialVelocity,
            float radius)
            : base(fireworkColor, initialVelocity, radius)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkOnlyTrailDto : FireworkOnlyTrail, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkOnlyTrailDto()
        {

        }

        public FireworkOnlyTrailDto(Vector3 launchPosition,
            float launchAngel,
            float initialVelocity,
            float angularVelocity,
            float launchInterval,
            FireworkColorType fireworkColor)
            : base(launchAngel, initialVelocity, angularVelocity, launchInterval, fireworkColor)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkBrocadeDto : FireworkBrocade, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkBrocadeDto()
        {

        }

        public FireworkBrocadeDto(Vector3 launchPosition,
            FireworkColorType fireworkColor,
            float initialVelocity,
            float radius)
            : base(fireworkColor, initialVelocity, radius)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkCrackleDto : FireworkCrackle, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkCrackleDto()
        {

        }

        public FireworkCrackleDto(Vector3 launchPosition,
            float initialVelocity)
            : base(initialVelocity)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkMineDto : FireworkMine, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkMineDto()
        {

        }

        public FireworkMineDto(Vector3 launchPosition,
            float initialVelocity)
            : base(initialVelocity)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkThreeLayersDto : FireworkThreeLayers, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public FireworkThreeLayersDto()
        {

        }

        public FireworkThreeLayersDto(Vector3 launchPosition,
            FireworkColorType fireworkColorInside,
            FireworkColorType fireworkColorOutside,
            float initialVelocity,
            float radius)
            : base(fireworkColorInside, fireworkColorOutside, initialVelocity, radius)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }

    public class FireworkImageDto : FireworkImage, IObjectWithPosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public int Width
        {
            get => width;
            set => width = value;
        }

        public int Height
        {
            get => height;
            set => height = value;
        }

        public byte[] RawImage
        {
            get => rawImage;
            set => rawImage = (value != null && value.Length <= maxImageByteLength) ? value : (new byte[] { });
        }

        public FireworkImageDto()
        {

        }

        public FireworkImageDto(Vector3 launchPosition,
            float initialVelocity,
            int width,
            int height,
            byte[] rawImage,
            DefaultImageType defaultImage)
            : base(initialVelocity, new ImageInfo (width, height, rawImage), defaultImage)
        {
            X = launchPosition.x;
            Y = launchPosition.y;
            Z = launchPosition.z;
        }
    }
}


