﻿using UnityEngine;
using System.Collections.Generic;
using Firework;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using Newtonsoft.Json.Converters;

namespace Dto
{
    public enum ModelType { Cake1, CrystallBall, Dog, JapanHouse, JapanRestaurant, StoneHouse };

    public class Pair
    {
        public FireworkBase Firework { get; set; }
        public Vector3 Position { get; set; }

        public Pair(FireworkBase firework, Vector3 position)
        {
            Firework = firework;
            Position = position;
        }
    }

    public class FireworkGroupDto
    {
        [JsonIgnore] public const int maxAudioByteLength = 2 * 1024 * 1024;

        public byte[] audio;

        public List<FireworkBase> Fireworks { get; set; }

        public long Tag { get; set; }

        [JsonConverter(typeof(StringEnumConverter))] public ModelType Model { get; set; }

        public byte[] Audio { get => audio ?? (new byte[] { }); set => audio = (value != null && value.Length <= maxAudioByteLength) ? value : (new byte[] { }); }

        public void SetPairs(List<Pair> fireworkPositionPairs)
        {
            Fireworks = new List<FireworkBase>();

            if (fireworkPositionPairs == null)
            {
                return;
            }

            foreach (Pair pair in fireworkPositionPairs)
            {
                switch (pair.Firework.Type)
                {
                    case FireworkType.Normal:
                        {
                            FireworkNormal firework = (FireworkNormal)pair.Firework;
                            Fireworks.Add(new FireworkNormalDto(pair.Position, firework.FireworkColor, firework.InitialVelocity, firework.Radius));
                            break;
                        }

                    case FireworkType.OnlyTrail:
                        {
                            FireworkOnlyTrail firework = (FireworkOnlyTrail)pair.Firework;
                            Fireworks.Add(new FireworkOnlyTrailDto(pair.Position, firework.LaunchAngel, firework.InitialVelocity, firework.AngularVelocity, firework.LaunchInterval, firework.FireworkColor));
                            break;
                        }

                    case FireworkType.Brocade:
                        {
                            FireworkBrocade firework = (FireworkBrocade)pair.Firework;
                            Fireworks.Add(new FireworkBrocadeDto(pair.Position, firework.FireworkColor, firework.InitialVelocity, firework.Radius));
                            break;
                        }

                    case FireworkType.Crackle:
                        {
                            FireworkCrackle firework = (FireworkCrackle)pair.Firework;
                            Fireworks.Add(new FireworkCrackleDto(pair.Position, firework.InitialVelocity));
                            break;
                        }

                    case FireworkType.Mine:
                        {
                            FireworkMine firework = (FireworkMine)pair.Firework;
                            Fireworks.Add(new FireworkMineDto(pair.Position, firework.InitialVelocity));
                            break;
                        }

                    case FireworkType.ThreeLayers:
                        {
                            FireworkThreeLayers firework = (FireworkThreeLayers)pair.Firework;
                            Fireworks.Add(new FireworkThreeLayersDto(pair.Position, firework.FireworkColorInside, firework.FireworkColorOutside, firework.InitialVelocity, firework.Radius));
                            break;
                        }

                    case FireworkType.Image:
                        {
                            FireworkImage firework = (FireworkImage)pair.Firework;
                            if (firework.ImageData == null)
                            {
                                Fireworks.Add(new FireworkImageDto(pair.Position, firework.InitialVelocity, 0, 0, new byte[] { }, firework.DefaultImage));
                            }
                            else
                            {
                                Fireworks.Add(new FireworkImageDto(pair.Position, firework.InitialVelocity, firework.ImageData.Width, firework.ImageData.Height, firework.ImageData.RawImage, firework.DefaultImage));
                            }
                            break;
                        }

                    default:
                        {
                            Debug.LogWarning("Unknown Firework Type.");
                            break;
                        }
                }
            }
        }

        public List<Pair> GetPairs()
        {
            if (Fireworks == null)
            {
                return null;
            }

            List<Pair> pairs = new List<Pair>();

            foreach(FireworkBase firework in Fireworks)
            {
                switch (firework.Type)
                {
                    case FireworkType.Normal:
                        {
                            FireworkNormalDto fireworkNormalDto = (FireworkNormalDto)firework;
                            FireworkNormal fireworkNormal = new FireworkNormal(fireworkNormalDto.FireworkColor, fireworkNormalDto.InitialVelocity, fireworkNormalDto.Radius);
                            Vector3 position = new Vector3(fireworkNormalDto.X, fireworkNormalDto.Y, fireworkNormalDto.Z);
                            pairs.Add(new Pair(fireworkNormal, position));
                            break;
                        }

                    case FireworkType.OnlyTrail:
                        {
                            FireworkOnlyTrailDto fireworkOnlyTrailDto = (FireworkOnlyTrailDto)firework;
                            FireworkOnlyTrail fireworkOnlyTrail = new FireworkOnlyTrail(fireworkOnlyTrailDto.LaunchAngel, fireworkOnlyTrailDto.InitialVelocity, fireworkOnlyTrailDto.AngularVelocity, fireworkOnlyTrailDto.LaunchInterval, fireworkOnlyTrailDto.FireworkColor);
                            Vector3 position = new Vector3(fireworkOnlyTrailDto.X, fireworkOnlyTrailDto.Y, fireworkOnlyTrailDto.Z);
                            pairs.Add(new Pair(fireworkOnlyTrail, position));
                            break;
                        }

                    case FireworkType.Brocade:
                        {
                            FireworkBrocadeDto fireworkBrocadeDto = (FireworkBrocadeDto)firework;
                            FireworkBrocade fireworkBrocade = new FireworkBrocade(fireworkBrocadeDto.FireworkColor, fireworkBrocadeDto.InitialVelocity, fireworkBrocadeDto.Radius);
                            Vector3 position = new Vector3(fireworkBrocadeDto.X, fireworkBrocadeDto.Y, fireworkBrocadeDto.Z);
                            pairs.Add(new Pair(fireworkBrocade, position));
                            break;
                        }

                    case FireworkType.Crackle:
                        {
                            FireworkCrackleDto fireworkCrackleDto = (FireworkCrackleDto)firework;
                            FireworkCrackle fireworkCrackle = new FireworkCrackle(fireworkCrackleDto.InitialVelocity);
                            Vector3 position = new Vector3(fireworkCrackleDto.X, fireworkCrackleDto.Y, fireworkCrackleDto.Z);
                            pairs.Add(new Pair(fireworkCrackle, position));
                            break;
                        }

                    case FireworkType.Mine:
                        {
                            FireworkMineDto fireworkMineDto = (FireworkMineDto)firework;
                            FireworkMine fireworkMine = new FireworkMine(fireworkMineDto.InitialVelocity);
                            Vector3 position = new Vector3(fireworkMineDto.X, fireworkMineDto.Y, fireworkMineDto.Z);
                            pairs.Add(new Pair(fireworkMine, position));
                            break;
                        }

                    case FireworkType.ThreeLayers:
                        {
                            FireworkThreeLayersDto fireworkThreeLayersDto = (FireworkThreeLayersDto)firework;
                            FireworkThreeLayers fireworkThreeLayers = new FireworkThreeLayers(fireworkThreeLayersDto.FireworkColorInside, fireworkThreeLayersDto.FireworkColorOutside, fireworkThreeLayersDto.InitialVelocity, fireworkThreeLayersDto.Radius);
                            Vector3 position = new Vector3(fireworkThreeLayersDto.X, fireworkThreeLayersDto.Y, fireworkThreeLayersDto.Z);
                            pairs.Add(new Pair(fireworkThreeLayers, position));
                            break;
                        }

                    case FireworkType.Image:
                        {
                            FireworkImageDto fireworkImageDto = (FireworkImageDto)firework;
                            FireworkImage fireworkImage = new FireworkImage(fireworkImageDto.InitialVelocity, fireworkImageDto.ImageData, fireworkImageDto.DefaultImage);
                            Vector3 position = new Vector3(fireworkImageDto.X, fireworkImageDto.Y, fireworkImageDto.Z);
                            pairs.Add(new Pair(fireworkImage, position));
                            break;
                        }

                    default:
                        {
                            Debug.LogWarning("Unknown Firework Type.");
                            break;
                        }
                }
            }

            return pairs;
        }
    }

    public class FireworkGroupDtoUtils
    {
        public static string GetJson(FireworkGroupDto fireworkGroup)
        {
            if (fireworkGroup.Fireworks == null)
            {
                throw new ArgumentNullException("FireworkGroup Uninitialized.");
            }
            return JsonConvert.SerializeObject(fireworkGroup);
        }

        public static FireworkGroupDto GetFireworkGroupDto(string json)
        {
            FireworkGroupDto fireworkGroup = new FireworkGroupDto();

            JObject jo = (JObject)JsonConvert.DeserializeObject(json);
            fireworkGroup.Tag = (long)jo.GetValue("Tag");
            fireworkGroup.Model = (ModelType)Enum.Parse(typeof(ModelType), (string)jo.GetValue("Model"));
            fireworkGroup.Audio = (byte[])jo.GetValue("Audio");

            JArray ja = (JArray)jo.GetValue("Fireworks");
            List<FireworkBase> fireworks = new List<FireworkBase>();
            foreach(JObject job in ja)
            {
                FireworkType type = (FireworkType) Enum.Parse(typeof(FireworkType), (string)job.GetValue("Type"));
                switch (type)
                {
                    case FireworkType.Normal:
                        {
                            fireworks.Add((FireworkNormalDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkNormalDto)));
                            break;
                        }

                    case FireworkType.OnlyTrail:
                        {
                            fireworks.Add((FireworkOnlyTrailDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkOnlyTrailDto)));
                            break;
                        }

                    case FireworkType.Brocade:
                        {
                            fireworks.Add((FireworkBrocadeDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkBrocadeDto)));
                            break;
                        }

                    case FireworkType.Crackle:
                        {
                            fireworks.Add((FireworkCrackleDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkCrackleDto)));
                            break;
                        }

                    case FireworkType.Mine:
                        {
                            fireworks.Add((FireworkMineDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkMineDto)));
                            break;
                        }

                    case FireworkType.ThreeLayers:
                        {
                            fireworks.Add((FireworkThreeLayersDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkThreeLayersDto)));
                            break;
                        }

                    case FireworkType.Image:
                        {
                            fireworks.Add((FireworkImageDto)JsonConvert.DeserializeObject(job.ToString(), typeof(FireworkImageDto)));
                            break;
                        }

                    default:
                        {
                            Debug.LogWarning("Unknown Firework Type.");
                            break;
                        }
                }
            }
            fireworkGroup.Fireworks = fireworks;

            return fireworkGroup;
        }
    }

    public class QueryDto
    {
        public long Tag { get; private set; }

        public QueryDto(long tag)
        {
            Tag = tag;
        }
    }
}


