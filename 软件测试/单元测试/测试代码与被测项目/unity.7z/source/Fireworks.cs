﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace Firework
{
    public enum FireworkType {None, Normal, OnlyTrail, Brocade, Crackle, Mine, ThreeLayers, Image};

    public enum FireworkColorType
    {
        Carmine,    // Li
        Yellow,     // Na
        Lilac,      // K
        BrickRed,   // Ca
        Crimson,    // Sr
        PaleGreen,  // Ba
        Green,      // Cu
    }



    public class FireworkBase
    {
        public FireworkBase()
        {
            
        }

        protected static float SetFloatWithBoundary(float value, float minValue, float maxValue)
        {
            return value > maxValue ? maxValue : (value < minValue ? minValue : value);
        }

        [JsonConverter(typeof(StringEnumConverter))]
        public virtual FireworkType Type
        {
            get { return FireworkType.None; }
        }
    }



    // The fireworks with initial velocity
    public class FireworkGeneral: FireworkBase
    {
        // Initial velocity (m/s)
        public virtual float InitialVelocity { get; set; }

        public FireworkGeneral(float initialVelocity): base()
        {
            InitialVelocity = initialVelocity;
        }
    }



    public class FireworkNormal: FireworkGeneral
    {
        // Default value
        [JsonIgnore] public const FireworkColorType defaultFireworkColor = FireworkColorType.Carmine;
        [JsonIgnore] public const float defaultInitialVelocity = 2.0f;
        [JsonIgnore] public const float defaultRadius = 0.33f;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1.5f;
        [JsonIgnore] public const float maxInitialVelocity = 2.5f;
        [JsonIgnore] public const float minRadius = 0.25f;
        [JsonIgnore] public const float maxRadius = 0.5f;

        // Private Attributes
        private float radius;
        private float initialVelocity;


        // Firework Color
        [JsonConverter(typeof(StringEnumConverter))]
        public FireworkColorType FireworkColor { get; set; }


        // get & set
        public float Radius 
        {
            get => radius; 
            set => radius = SetFloatWithBoundary(value, minRadius, maxRadius); 
        }

        public override float InitialVelocity
        {
            get => initialVelocity; 
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity); 
        }


        public FireworkNormal(FireworkColorType fireworkColor = defaultFireworkColor,
            float initialVelocity = defaultInitialVelocity,
            float radius = defaultRadius)
            : base(initialVelocity: initialVelocity)
        {
            FireworkColor = fireworkColor;
            Radius = radius;
        }

        public override FireworkType Type
        {
            get { return FireworkType.Normal; }
        }
    }



    public class FireworkOnlyTrail: FireworkGeneral
    {
        // Default value
        [JsonIgnore] public const float defaultLaunchAngel = 55.0f;
        [JsonIgnore] public const float defaultInitialVelocity = 0.5f;
        [JsonIgnore] public const float defaultAngularVelocity = 0.05f;
        [JsonIgnore] public const float defaultLaunchInterval = 0.5f;
        [JsonIgnore] public const FireworkColorType defaultFireworkColor = FireworkColorType.Yellow;

        // Boundary
        [JsonIgnore] public const float minLaunchAngel = 0;
        [JsonIgnore] public const float maxLaunchAngel = 90;
        [JsonIgnore] public const float minInitialVelocity = 0.25f;
        [JsonIgnore] public const float maxInitialVelocity = 0.75f;
        [JsonIgnore] public const float minAngularVelocity = 0;
        [JsonIgnore] public const float maxAngularVelocity = 1;
        [JsonIgnore] public const float minLaunchInterval = 0.1f;
        [JsonIgnore] public const float maxLaunchInterval = 10;

        // Private Attributes
        private float launchAngel;
        private float initialVelocity;
        private float angularVelocity;
        private float launchInterval;


        [JsonConverter(typeof(StringEnumConverter))]
        public FireworkColorType FireworkColor { get; set; }


        // get & set
        // The angel between the horizontal plane and the direction of initial velocity (degrees)
        public float LaunchAngel 
        { 
            get => launchAngel; 
            set => launchAngel = SetFloatWithBoundary(value, minLaunchAngel, maxLaunchAngel); 
        }

        // Spin angular velocity (circles per second)
        public float AngularVelocity 
        {
            get => angularVelocity;
            set => angularVelocity = SetFloatWithBoundary(value, minAngularVelocity, maxAngularVelocity); 
        }

        // Launch interval (seconds)
        public float LaunchInterval 
        { 
            get => launchInterval;
            set => launchInterval = SetFloatWithBoundary(value, minLaunchInterval, maxLaunchInterval);
        }

        public override float InitialVelocity 
        { 
            get => initialVelocity; 
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity); 
        }

        public FireworkOnlyTrail(float launchAngel = defaultLaunchAngel, 
            float initialVelocity = defaultInitialVelocity, 
            float angularVelocity = defaultAngularVelocity, 
            float launchInterval = defaultLaunchInterval,
            FireworkColorType fireworkColor = defaultFireworkColor) 
            : base(initialVelocity: initialVelocity)
        {
            LaunchAngel = launchAngel;
            AngularVelocity = angularVelocity;
            LaunchInterval = launchInterval;
            FireworkColor = fireworkColor;
        }

        public override FireworkType Type
        {
            get { return FireworkType.OnlyTrail; }
        }
    }



    public class FireworkBrocade: FireworkGeneral
    {
        // Default value
        [JsonIgnore] public const FireworkColorType defaultFireworkColor = FireworkColorType.Green;
        [JsonIgnore] public const float defaultInitialVelocity = 2.0f;
        [JsonIgnore] public const float defaultRadius = 0.25f;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1.5f;
        [JsonIgnore] public const float maxInitialVelocity = 2.5f;
        [JsonIgnore] public const float minRadius = 0.25f;
        [JsonIgnore] public const float maxRadius = 0.5f;

        // Private Attributes
        private float initialVelocity;
        private float radius;


        [JsonConverter(typeof(StringEnumConverter))]
        public FireworkColorType FireworkColor { get; set; }

        public float Radius 
        {
            get => radius;
            set => radius = SetFloatWithBoundary(value, minRadius, maxRadius);
        }

        public override float InitialVelocity 
        { 
            get => initialVelocity; 
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity); 
        }

        public FireworkBrocade(FireworkColorType fireworkColor = defaultFireworkColor,
            float initialVelocity = defaultInitialVelocity,
            float radius = defaultRadius)
            : base(initialVelocity: initialVelocity)
        {
            FireworkColor = fireworkColor;
            Radius = radius;
        }

        public override FireworkType Type
        {
            get { return FireworkType.Brocade; }
        }
    }



    public class FireworkCrackle: FireworkGeneral
    {
        // Default Value
        [JsonIgnore] public const float defaultInitialVelocity = 1.5f;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1;
        [JsonIgnore] public const float maxInitialVelocity = 2;

        // Private Attributes
        private float initialVelocity;


        public override float InitialVelocity 
        { 
            get => initialVelocity; 
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity); 
        }

        public FireworkCrackle(float initialVelocity = defaultInitialVelocity) 
            : base(initialVelocity: initialVelocity)
        {

        }

        public override FireworkType Type
        {
            get { return FireworkType.Crackle; }
        }
    }



    public class FireworkMine: FireworkGeneral
    {
        // Default Value
        [JsonIgnore] public const float defaultInitialVelocity = 1.5f;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1;
        [JsonIgnore] public const float maxInitialVelocity = 2;

        // Private Attributes
        private float initialVelocity;


        public override float InitialVelocity
        {
            get => initialVelocity;
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity);
        }

        public FireworkMine(float initialVelocity = defaultInitialVelocity)
            : base(initialVelocity: initialVelocity)
        {

        }

        public override FireworkType Type
        {
            get { return FireworkType.Mine; }
        }
    }



    public class FireworkThreeLayers: FireworkGeneral
    {
        // Default Value
        [JsonIgnore] public const FireworkColorType defaultFireworkColorInside = FireworkColorType.Crimson;
        [JsonIgnore] public const FireworkColorType defaultFireworkColorOutside = FireworkColorType.Lilac;
        [JsonIgnore] public const float defaultInitialVelocity = 2.0f;
        [JsonIgnore] public const float defaultRadius = 0.33f;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1.5f;
        [JsonIgnore] public const float maxInitialVelocity = 2.5f;
        [JsonIgnore] public const float minRadius = 0.2f;
        [JsonIgnore] public const float maxRadius = 0.33f;

        // Private Attributes
        private float initialVelocity;
        private float radius;


        [JsonConverter(typeof(StringEnumConverter))]
        public FireworkColorType FireworkColorInside { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public FireworkColorType FireworkColorOutside { get; set; }

        public float Radius
        {
            get => radius;
            set => radius = SetFloatWithBoundary(value, minRadius, maxRadius);
        }

        public override float InitialVelocity
        {
            get => initialVelocity;
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity);
        }

        public FireworkThreeLayers(FireworkColorType fireworkColorInside = defaultFireworkColorInside,
            FireworkColorType fireworkColorOutside = defaultFireworkColorOutside,
            float initialVelocity = defaultInitialVelocity,
            float radius = defaultRadius)
            : base(initialVelocity: initialVelocity)
        {
            FireworkColorInside = fireworkColorInside;
            FireworkColorOutside = fireworkColorOutside;
            Radius = radius;
        }

        public override FireworkType Type
        {
            get { return FireworkType.ThreeLayers; }
        }
    }



    public class FireworkImage: FireworkGeneral
    {
        public class ImageInfo
        {
            public int Width { get; private set; }
            public int Height { get; private set; }
            public byte[] RawImage { get; private set; }

            public ImageInfo(int width, int height, byte[] rawImage)
            {
                Width = width;
                Height = height;
                RawImage = rawImage ?? new byte[] { };
            }
        }

        public enum DefaultImageType { Bear1, Bear2, Bird1, Bird2, BlueButterfly, Boy1, Boy2, Butterfly2, Butterfly3,
        Chicken, Fox, Girl1, GoodLuck, ILOVEYOU, HappyBirthday, Monkey, PearlGirl, RedButterfly, SafeAndSound, 
        SnowFlake, StaryNight1, StaryNight2, SunFlower, Tiger, VanGogh, None }

        // Default Value
        [JsonIgnore] public const float defaultInitialVelocity = 2.0f;
        [JsonIgnore] public const ImageInfo defaultImageData = null;
        [JsonIgnore] public const DefaultImageType defaultDefaultImage = DefaultImageType.HappyBirthday;

        // Boundary
        [JsonIgnore] public const float minInitialVelocity = 1.5f;
        [JsonIgnore] public const float maxInitialVelocity = 2.5f;
        [JsonIgnore] public const int maxImageByteLength = 128 * 1024;
        
        // Private Attributes
        private float initialVelocity;
        protected int width;
        protected int height;
        protected byte[] rawImage;

        [JsonIgnore]
        public ImageInfo ImageData 
        {
            get
            {
                return rawImage.Length == 0 ? null : new ImageInfo(width, height, rawImage);
            }
            set
            {
                if (value != null && value.RawImage.Length <= maxImageByteLength)
                {
                    width = value.Width;
                    height = value.Height;
                    rawImage = value.RawImage;
                }
                else
                {
                    rawImage = new byte[] { };
                }
            }
        }

        [JsonConverter(typeof(StringEnumConverter))]
        public DefaultImageType DefaultImage { get; set; }

        public override float InitialVelocity
        {
            get => initialVelocity;
            set => initialVelocity = SetFloatWithBoundary(value, minInitialVelocity, maxInitialVelocity);
        }

        public FireworkImage(float initialVelocity = defaultInitialVelocity,
            ImageInfo imageData = defaultImageData,
            DefaultImageType defaultImage = defaultDefaultImage)
            :base(initialVelocity)
        {
            ImageData = imageData;
            DefaultImage = defaultImage;
        }

        public override FireworkType Type
        {
            get { return FireworkType.Image; }
        }
    }
}


