package com.fireworklab.backend.controller;

import com.alibaba.fastjson.JSONObject;
import com.fireworklab.backend.dto.TagOrderListDto;
import com.fireworklab.backend.dto.UserListDto;
import com.fireworklab.backend.entity.QrCodeUser;
import com.fireworklab.backend.entity.QrCodeUserType;
import com.fireworklab.backend.repository.FireworkGroupRepository;
import com.fireworklab.backend.service.QrCodeService;
import com.fireworklab.backend.utils.session.SessionUtil;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.*;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;

public class QrCodeControllerTest {

    @InjectMocks
    private QrCodeController qrCodeController;

    @Mock
    private QrCodeService qrCodeService;

    @Mock
    private FireworkGroupRepository fireworkGroupRepository;

    // a root user
    final Integer RootId = 1;
    final String RootUsername = "root";
    final String RootPassword = "root-password";

    // a pending user
    final Integer PendingId = 2;
    final String PendingUsername = "PENDING_USERNAME";
    final String PendingPassword = "123456";

    // a normal user
    final Integer NormalId = 3;
    final String NormalUsername = "NORMAL_USERNAME";
    final String NormalPassword = "12345678";

    // a forbidden user
    final Integer ForbiddenId = 4;
    final String ForbiddenUsername = "FORBIDDEN_USERNAME";
    final String ForbiddenPassword = "1234567890";

    private List<QrCodeUser> userList;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        QrCodeUser rootUser = new QrCodeUser();
        rootUser.setId(RootId);
        rootUser.setUserType(QrCodeUserType.MANAGER);
        rootUser.setUsername(RootUsername);
        rootUser.setPassword(RootPassword);

        QrCodeUser pendingUser = new QrCodeUser();
        pendingUser.setId(PendingId);
        pendingUser.setUserType(QrCodeUserType.PENDING);
        pendingUser.setUsername(PendingUsername);
        pendingUser.setPassword(PendingPassword);

        QrCodeUser normalUser = new QrCodeUser();
        normalUser.setId(NormalId);
        normalUser.setUserType(QrCodeUserType.NORMAL);
        normalUser.setUsername(NormalUsername);
        normalUser.setPassword(NormalPassword);

        QrCodeUser forbiddenUser = new QrCodeUser();
        forbiddenUser.setId(ForbiddenId);
        forbiddenUser.setUserType(QrCodeUserType.FORBIDDEN);
        forbiddenUser.setUsername(ForbiddenUsername);
        forbiddenUser.setPassword(ForbiddenPassword);

        userList = new ArrayList<>();
        userList.add(rootUser);
        userList.add(normalUser);
        userList.add(pendingUser);
        userList.add(forbiddenUser);
    }

    private void setQrCodeUser () {
        Mockito.when(qrCodeService.Register(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        for (QrCodeUser user : userList) {
            Mockito.when(qrCodeService.Register(eq(user.getUsername()), Mockito.any(), Mockito.any())).thenReturn(false);
        }

        Mockito.when(qrCodeService.Login(Mockito.any(), Mockito.any())).thenReturn(false);
        for (QrCodeUser user : userList) {
            Mockito.when(qrCodeService.Login(user.getUsername(), user.getPassword())).thenReturn(true);
        }
    }



    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/check-session.csv"})
    void checkSession (String sessionJson, Integer result) throws NoSuchAlgorithmException {
        if (sessionJson == null) {
            sessionJson = "";
        }

        if (sessionJson.equals("NULL")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.CheckSession().getStatus());
            }
        }
        else {
            KeyPairGenerator keyPairGenerator;
            try {
                keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            } catch (Exception e) {
                return;
            }
            keyPairGenerator.initialize(1024);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            JSONObject json = new JSONObject();
            json.put(SessionUtil.USERNAME, sessionJson);
            json.put(SessionUtil.PRIVATE_TOKEN, keyPair.getPrivate());
            json.put(SessionUtil.PUBLIC_TOKEN, keyPair.getPublic());

            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(json);
                assertEquals(result, qrCodeController.CheckSession().getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/register.csv"})
    void register (String sessionJson, String username, String message, String password, Integer result) {
        JSONObject json = new JSONObject();
        json.put("username", username);
        json.put("message", message);
        json.put("password", password);

        if (Objects.equals(sessionJson, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.Register(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                KeyPairGenerator keyPairGenerator;
                try {
                    keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                } catch (Exception e) {
                    return;
                }
                keyPairGenerator.initialize(1024);
                KeyPair keyPair = keyPairGenerator.generateKeyPair();

                JSONObject sampleJson = new JSONObject();
                sampleJson.put(SessionUtil.PRIVATE_TOKEN, keyPair.getPrivate());

                Cipher cipher;
                try {
                    cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());
                    json.put("password",  Base64.encodeBase64String(cipher.doFinal(json.getString("password").getBytes(StandardCharsets.UTF_8))));
                } catch (Exception ignored) {

                }

                setQrCodeUser();

                mock.when(SessionUtil::getAuth).thenReturn(sampleJson);
                assertEquals(result, qrCodeController.Register(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/login.csv"})
    void login (String sessionJsonUsername, String username, String password, Integer result) {
        JSONObject json = new JSONObject();
        json.put("username", username);
        json.put("password", password);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.Login(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                KeyPairGenerator keyPairGenerator;
                try {
                    keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                } catch (Exception e) {
                    return;
                }
                keyPairGenerator.initialize(1024);
                KeyPair keyPair = keyPairGenerator.generateKeyPair();

                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);
                sessionJson.put(SessionUtil.PRIVATE_TOKEN, keyPair.getPrivate());

                Cipher cipher;
                try {
                    cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());
                    json.put("password", Base64.encodeBase64String(cipher.doFinal(json.getString("password").getBytes(StandardCharsets.UTF_8))));
                } catch (Exception ignored) {

                }

                setQrCodeUser();

                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.Login(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/logout.csv"})
    void logout (String sessionJsonUsername, Integer result) {

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.Logout().getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.Logout().getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/get-zip-images.csv"})
    void getZipImages (String sessionJsonUsername, Integer tagOrderId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("tagOrderId", tagOrderId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.GetZipImages(json) != null ? 1 : 0);
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                List<BitMatrix> bitMatrices = new ArrayList<>();
                for (int i = 0; i < 5; ++i) {
                    try {
                        bitMatrices.add(new QRCodeWriter().encode(Integer.toString(i), BarcodeFormat.QR_CODE, 260, 260));
                    } catch (Exception ignored) {

                    }
                }

                Mockito.when(qrCodeService.GetImageMatrix(Mockito.any(), Mockito.any())).thenReturn(bitMatrices);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);

                assertEquals(result, qrCodeController.GetZipImages(json) != null ? 1 : 0);
            } catch (Exception ignored) {

            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/generate-random.csv"})
    void generateRandom (String sessionJsonUsername, Integer number, Integer orderId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("number", number);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.GenerateRandomTags(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.GenerateRandomTags(Mockito.any(), eq(number))).thenReturn(orderId);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.GenerateRandomTags(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/exist-tag-order.csv"})
    void existTagOrders (String sessionJsonUsername, Integer pageInd, Integer pageSize, Integer result) {
        JSONObject json = new JSONObject();
        json.put("pageInd", pageInd);
        json.put("pageSize", pageSize);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.ExistTagOrders(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.GetTagOrders(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
                Mockito.when(qrCodeService.GetTagOrders(eq(RootUsername), Mockito.any(), Mockito.any())).thenReturn(new TagOrderListDto());
                Mockito.when(qrCodeService.GetTagOrders(eq(NormalUsername), Mockito.any(), Mockito.any())).thenReturn(new TagOrderListDto());
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.ExistTagOrders(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/get-tag-order.csv"})
    void getTagOrders (String sessionJsonUsername, Integer pageInd, Integer pageSize, Integer result) {
        JSONObject json = new JSONObject();
        json.put("pageInd", pageInd);
        json.put("pageSize", pageSize);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.GetTagOrders(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.GetTagOrders(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
                Mockito.when(qrCodeService.GetTagOrders(eq(RootUsername), Mockito.any(), Mockito.any())).thenReturn(new TagOrderListDto());
                Mockito.when(qrCodeService.GetTagOrders(eq(NormalUsername), Mockito.any(), Mockito.any())).thenReturn(new TagOrderListDto());
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.GetTagOrders(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/delete-tag-order.csv"})
    void deleteTagOrders (String sessionJsonUsername, Integer tagOrderId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("tagOrderId", tagOrderId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.DeleteTagOrders(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.DeleteTagOrders(Mockito.any(), Mockito.any())).thenReturn(false);
                Mockito.when(qrCodeService.DeleteTagOrders(eq(RootUsername), Mockito.any())).thenReturn(true);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.DeleteTagOrders(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/check-tag.csv"})
    void checkTag (Integer tag, Integer result) {
        JSONObject json = new JSONObject();
        json.put("Tag", tag);

        Mockito.when(qrCodeService.CheckTag(Mockito.any())).thenReturn(false);
        Mockito.when(qrCodeService.CheckTag(1L)).thenReturn(true);
        assertEquals(result, qrCodeController.CheckTag(json).getStatus());
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/get-user-list.csv"})
    void getUserList (String sessionJsonUsername, Integer pageInd, Integer pageSize, Integer result) {
        JSONObject json = new JSONObject();
        json.put("pageInd", pageInd);
        json.put("pageSize", pageSize);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.GetUserList(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.GetUserList(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
                Mockito.when(qrCodeService.GetUserList(eq(RootUsername), Mockito.any(), Mockito.any())).thenReturn(new UserListDto());
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.GetUserList(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/delete-users.csv"})
    void deleteUsers (String sessionJsonUsername, Integer userId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("userId", userId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.DeleteUser(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.DeleteUsers(Mockito.any(), Mockito.any())).thenReturn(false);
                Mockito.when(qrCodeService.DeleteUsers(eq(RootUsername), Mockito.any())).thenReturn(true);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.DeleteUser(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/auth-users.csv"})
    void authUsers (String sessionJsonUsername, Integer userId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("userId", userId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.AuthUser(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.AuthUsers(Mockito.any(), Mockito.any())).thenReturn(false);
                Mockito.when(qrCodeService.AuthUsers(eq(RootUsername), Mockito.any())).thenReturn(true);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.AuthUser(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/block-users.csv"})
    void blockUsers (String sessionJsonUsername, Integer userId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("userId", userId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.BlockUser(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.BlockUsers(Mockito.any(), Mockito.any())).thenReturn(false);
                Mockito.when(qrCodeService.BlockUsers(eq(RootUsername), Mockito.any())).thenReturn(true);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.BlockUser(json).getStatus());
            }
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/controller-test-data/unblock-users.csv"})
    void unblockUsers (String sessionJsonUsername, Integer userId, Integer result) {
        JSONObject json = new JSONObject();
        json.put("userId", userId);

        if (Objects.equals(sessionJsonUsername, "null")) {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                mock.when(SessionUtil::getAuth).thenReturn(null);
                assertEquals(result, qrCodeController.UnBlockUser(json).getStatus());
            }
        }
        else {
            try (MockedStatic<SessionUtil> mock = Mockito.mockStatic(SessionUtil.class)) {
                JSONObject sessionJson = new JSONObject();
                sessionJson.put(SessionUtil.USERNAME, sessionJsonUsername);

                Mockito.when(qrCodeService.UnBlockUsers(Mockito.any(), Mockito.any())).thenReturn(false);
                Mockito.when(qrCodeService.UnBlockUsers(eq(RootUsername), Mockito.any())).thenReturn(true);
                mock.when(SessionUtil::getAuth).thenReturn(sessionJson);
                assertEquals(result, qrCodeController.UnBlockUser(json).getStatus());
            }
        }
    }
}
