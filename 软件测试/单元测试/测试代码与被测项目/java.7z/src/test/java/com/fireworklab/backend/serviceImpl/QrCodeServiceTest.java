package com.fireworklab.backend.serviceImpl;

import com.fireworklab.backend.entity.*;
import com.fireworklab.backend.repository.QrCodeUserRepository;
import com.fireworklab.backend.repository.TagOrderRepository;
import com.fireworklab.backend.repository.TagRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class QrCodeServiceTest {

    @InjectMocks
    private QrCodeServiceImpl qrCodeService;

    @Mock
    private QrCodeUserRepository qrCodeUserRepository;

    @Mock
    private TagOrderRepository tagOrderRepository;

    @Mock
    private TagRepository tagRepository;

    /*
        definition for some constant value
     */

    // a root user
    final Integer RootId = 1;
    final String RootUsername = "root";
    final String RootPassword = "root-password";

    // a pending user
    final Integer PendingId = 2;
    final String PendingUsername = "PENDING_USERNAME";
    final String PendingPassword = "123456";

    // a normal user
    final Integer NormalId = 3;
    final String NormalUsername = "NORMAL_USERNAME";
    final String NormalPassword = "12345678";

    // a forbidden user
    final Integer ForbiddenId = 4;
    final String ForbiddenUsername = "FORBIDDEN_USERNAME";
    final String ForbiddenPassword = "1234567890";

    private List<QrCodeUser> userList;

    /*
        end
     */



    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        QrCodeUser rootUser = new QrCodeUser();
        rootUser.setId(RootId);
        rootUser.setUserType(QrCodeUserType.MANAGER);
        rootUser.setUsername(RootUsername);
        rootUser.setPassword(RootPassword);

        QrCodeUser pendingUser = new QrCodeUser();
        pendingUser.setId(PendingId);
        pendingUser.setUserType(QrCodeUserType.PENDING);
        pendingUser.setUsername(PendingUsername);
        pendingUser.setPassword(PendingPassword);

        QrCodeUser normalUser = new QrCodeUser();
        normalUser.setId(NormalId);
        normalUser.setUserType(QrCodeUserType.NORMAL);
        normalUser.setUsername(NormalUsername);
        normalUser.setPassword(NormalPassword);

        QrCodeUser forbiddenUser = new QrCodeUser();
        forbiddenUser.setId(ForbiddenId);
        forbiddenUser.setUserType(QrCodeUserType.FORBIDDEN);
        forbiddenUser.setUsername(ForbiddenUsername);
        forbiddenUser.setPassword(ForbiddenPassword);

        userList = new ArrayList<>();
        userList.add(rootUser);
        userList.add(normalUser);
        userList.add(pendingUser);
        userList.add(forbiddenUser);
    }

    private void setExistUser() {
        Mockito.when(qrCodeUserRepository.getByUsername(Mockito.any())).thenReturn(null);
        for (QrCodeUser user: userList) {
            Mockito.when(qrCodeUserRepository.getByUsername(user.getUsername())).thenReturn(user);
        }
        Mockito.when(qrCodeUserRepository.getByUsername(null)).thenThrow(RuntimeException.class);

        Mockito.when(qrCodeUserRepository.existsByUsername(Mockito.any())).thenReturn(false);
        for (QrCodeUser user: userList) {
            Mockito.when(qrCodeUserRepository.existsByUsername(user.getUsername())).thenReturn(true);
        }

        Mockito.when(qrCodeUserRepository.getById(Mockito.any())).thenReturn(null);
        for (QrCodeUser user: userList) {
            Mockito.when(qrCodeUserRepository.getById(user.getId())).thenReturn(user);
        }
    }

    private String filterNull (String origin) {
        return origin == null ? "" : origin;
    }



    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/register.csv"})
    void register(String username, String password, String message, Boolean result) {
        setExistUser();
        username = filterNull(username);
        password = filterNull(password);
        message = filterNull(message);
        assertEquals(result ,qrCodeService.Register(username, password, message));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/login.csv"})
    void login(String username, String password, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.Login(username, password));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/check-root.csv"})
    void checkRoot(String username, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.CheckRoot(username));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/generate-random.csv"})
    void generateRandom(String username, Integer number, Integer result) {
        TagOrder tagOrder = new TagOrder();
        tagOrder.setId(number);

        setExistUser();
        Mockito.when(tagOrderRepository.save(Mockito.any())).thenThrow(new RuntimeException()).thenReturn(tagOrder);
        assertEquals(result, qrCodeService.GenerateRandomTags(username, number));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/get-image-matrix.csv"})
    void getImageMatrix(String username, Integer tagOrderId, Boolean errorTag, Boolean resultIsNull) {
        TagOrder tagOrder = new TagOrder();
        if (!errorTag) {
            Tag tag = new Tag();
            tag.setId(1L);
            tagOrder.setTagList(new ArrayList<>());
            tagOrder.getTagList().add(tag);
        }
        for (QrCodeUser user : userList) {
            if (user.getUsername().equals(username)) {
                tagOrder.setQrCodeUser(userList.get(0));
                break;
            }
        }

        Mockito.when(tagOrderRepository.getById(Mockito.any())).thenReturn(tagOrder);
        assertEquals(resultIsNull, qrCodeService.GetImageMatrix(username, tagOrderId) == null);
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/get-tag-orders.csv"})
    void getTagOrder(String username, Integer pageInd, Integer pageSize, Boolean empty, Integer result) {
        Page<TagOrder> tagOrders;
        List<TagOrder> tagOrderList = new ArrayList<>();
        if (!empty) {
            for (int i = 0; i < pageSize; ++i) {
                TagOrder tagOrder = new TagOrder();
                tagOrder.setTagList(new ArrayList<>());
                tagOrder.setQrCodeUser(new QrCodeUser());
                tagOrderList.add(tagOrder);
            }
        }
        tagOrders = new PageImpl<>(tagOrderList);

        setExistUser();
        Mockito.when(tagOrderRepository.findAll(Mockito.any(PageRequest.class))).thenReturn(tagOrders);
        Mockito.when(tagOrderRepository.findAllByQrCodeUser(Mockito.any(), Mockito.any(PageRequest.class))).thenReturn(tagOrders);

        if (result == null) {
            assertNull(qrCodeService.GetTagOrders(username, pageInd, pageSize));
        }
        else {
            assertEquals(result, qrCodeService.GetTagOrders(username, pageInd, pageSize).getTagOrders().size());
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/delete-tag-order.csv"})
    void deleteTagOrder(String username, Integer tagOrderId, Boolean needThrow, Boolean result) {
        TagOrder tagOrder = new TagOrder();
        tagOrder.setQrCodeUser(userList.get(0));

        if (needThrow) {
            Mockito.when(tagOrderRepository.getById(tagOrderId)).thenThrow();
        }
        else {
            setExistUser();
            Mockito.when(tagOrderRepository.getById(tagOrderId)).thenReturn(tagOrder);
        }
        assertEquals(result, qrCodeService.DeleteTagOrders(username, tagOrderId));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/check-tag.csv"})
    void checkTag(Long tag, Boolean result) {
        Mockito.when(tagRepository.existsById(tag)).thenReturn(result);
        assertEquals(result, qrCodeService.CheckTag(tag));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/get-user-list.csv"})
    void getUserList(String username, Integer pageInd, Integer pageSize, Boolean empty, Integer result) {
        Page<QrCodeUser> qrCodeUsers;
        List<QrCodeUser> qrCodeUserList = new ArrayList<>();
        if (!empty) {
            for (int i = 0; i < pageSize; ++i) {
                QrCodeUser qrCodeUser = new QrCodeUser();
                qrCodeUser.setUserMessage(new UserMessage());
                qrCodeUserList.add(qrCodeUser);
            }
        }
        qrCodeUsers = new PageImpl<>(qrCodeUserList);

        setExistUser();
        Mockito.when(qrCodeUserRepository.findAll(Mockito.any(PageRequest.class))).thenReturn(qrCodeUsers);

        if (result == null) {
            assertNull(qrCodeService.GetUserList(username, pageInd, pageSize));
        }
        else {
            assertEquals(result, qrCodeService.GetUserList(username, pageInd, pageSize).getUserList().size());
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/delete-users.csv"})
    void deleteUsers(String username, Integer userId, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.DeleteUsers(username, userId));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/auth-users.csv"})
    void authUsers(String username, Integer userId, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.AuthUsers(username, userId));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/block-users.csv"})
    void blockUsers(String username, Integer userId, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.BlockUsers(username, userId));
    }

    @ParameterizedTest
    @CsvFileSource(resources = {"/server-test-data/unblock-users.csv"})
    void unblockUsers(String username, Integer userId, Boolean result) {
        setExistUser();
        assertEquals(result, qrCodeService.UnBlockUsers(username, userId));
    }
}
