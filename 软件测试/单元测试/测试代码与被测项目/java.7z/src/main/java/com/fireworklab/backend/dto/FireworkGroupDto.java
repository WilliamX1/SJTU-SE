package com.fireworklab.backend.dto;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FireworkGroupDto {

    @JsonProperty("Fireworks")
    private List<FireworkBaseDto> Fireworks;

    @JsonProperty("Tag")
    private Long Tag;

    @JsonProperty("Model")
    private ModelType Model;

    @JsonProperty("Audio")
    private byte[] Audio;

    public static FireworkGroupDto GetFireworkGroupDto(JSONObject json) {

        FireworkGroupDto fireworkGroup = new FireworkGroupDto();
        List<FireworkBaseDto> fireworks = new ArrayList<>();
        Long tag;
        ModelType model;
        byte[] Audio;

        tag = json.getLong("Tag");
        model = ModelType.valueOf(json.getString("Model"));
        JSONArray fireworkArray = json.getJSONArray("Fireworks");
        Audio = json.getBytes("Audio");

        for (int i = 0; i < fireworkArray.size(); ++i) {
            JSONObject jsonObject = fireworkArray.getJSONObject(i);

            FireworkType type = FireworkType.valueOf(jsonObject.getString("Type"));

            switch (type) {

                case Normal:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkNormalDto.class));
                    break;
                case OnlyTrail:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkOnlyTrailDto.class));
                    break;
                case Brocade:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkBrocadeDto.class));
                    break;
                case Crackle:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkCrackleDto.class));
                    break;
                case Mine:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkMineDto.class));
                    break;
                case ThreeLayers:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkThreeLayersDto.class));
                    break;
                case Image:
                    fireworks.add(JSON.parseObject(jsonObject.toJSONString(), FireworkImageDto.class));
                    break;
                default:
                    System.out.println("Unknown firework type.");
            }
        }

        fireworkGroup.setFireworks(fireworks);
        fireworkGroup.setTag(tag);
        fireworkGroup.setModel(model);
        fireworkGroup.setAudio(Audio);
        return fireworkGroup;
    }

    public static FireworkGroupDto GetFireworkGroupDto(FireworkGroup fireworkGroup) {

        FireworkGroupDto fireworkGroupDto = new FireworkGroupDto();
        List<FireworkBaseDto> fireworks = new ArrayList<>();

        for (FireworkBase fireworkBase : fireworkGroup.getFireworkList()) {

            if (FireworkNormal.class.equals(fireworkBase.getClass())) {
                FireworkNormal fireworkNormal = (FireworkNormal) fireworkBase;
                fireworks.add(new FireworkNormalDto(FireworkType.Normal,
                        fireworkNormal.getX(),
                        fireworkNormal.getY(),
                        fireworkNormal.getZ(),
                        fireworkNormal.getColor(),
                        fireworkNormal.getInitialVelocity(),
                        fireworkNormal.getRadius()));

            } else if (FireworkOnlyTrail.class.equals(fireworkBase.getClass())) {
                FireworkOnlyTrail fireworkOnlyTrail = (FireworkOnlyTrail) fireworkBase;
                fireworks.add(new FireworkOnlyTrailDto(FireworkType.OnlyTrail,
                        fireworkOnlyTrail.getX(),
                        fireworkOnlyTrail.getY(),
                        fireworkOnlyTrail.getZ(),
                        fireworkOnlyTrail.getLaunchAngel(),
                        fireworkOnlyTrail.getInitialVelocity(),
                        fireworkOnlyTrail.getAngularVelocity(),
                        fireworkOnlyTrail.getLaunchInterval(),
                        fireworkOnlyTrail.getColor()));

            } else if (FireworkBrocade.class.equals(fireworkBase.getClass())) {
                FireworkBrocade fireworkBrocade = (FireworkBrocade) fireworkBase;
                fireworks.add(new FireworkBrocadeDto(FireworkType.Brocade,
                        fireworkBrocade.getX(),
                        fireworkBrocade.getY(),
                        fireworkBrocade.getZ(),
                        fireworkBrocade.getColor(),
                        fireworkBrocade.getInitialVelocity(),
                        fireworkBrocade.getRadius()));
                
            } else if (FireworkCrackle.class.equals(fireworkBase.getClass())) {
                FireworkCrackle fireworkCrackle = (FireworkCrackle) fireworkBase;
                fireworks.add(new FireworkCrackleDto(FireworkType.Crackle,
                        fireworkCrackle.getX(),
                        fireworkCrackle.getY(),
                        fireworkCrackle.getZ(),
                        fireworkCrackle.getInitialVelocity()));
                
            } else if (FireworkMine.class.equals(fireworkBase.getClass())) {
                FireworkMine fireworkMine = (FireworkMine) fireworkBase;
                fireworks.add(new FireworkMineDto(FireworkType.Mine,
                        fireworkMine.getX(),
                        fireworkMine.getY(),
                        fireworkMine.getZ(),
                        fireworkMine.getInitialVelocity()));
                
            } else if (FireworkThreeLayers.class.equals(fireworkBase.getClass())) {
                FireworkThreeLayers fireworkThreeLayers = (FireworkThreeLayers) fireworkBase;
                fireworks.add(new FireworkThreeLayersDto(FireworkType.ThreeLayers,
                        fireworkThreeLayers.getX(),
                        fireworkThreeLayers.getY(),
                        fireworkThreeLayers.getZ(),
                        fireworkThreeLayers.getColorInside(),
                        fireworkThreeLayers.getColorOutside(),
                        fireworkThreeLayers.getInitialVelocity(),
                        fireworkThreeLayers.getRadius()));
                
            } else if (FireworkImage.class.equals(fireworkBase.getClass())) {
                FireworkImage fireworkImage = (FireworkImage) fireworkBase;
                fireworks.add(new FireworkImageDto(FireworkType.Image,
                        fireworkImage.getX(),
                        fireworkImage.getY(),
                        fireworkImage.getZ(),
                        fireworkImage.getInitialVelocity(),
                        fireworkImage.getWidth(),
                        fireworkImage.getHeight(),
                        fireworkImage.getRawImage().getContent(),
                        fireworkImage.getDefaultImage()));

            } else {
                System.out.println("Unknown firework type.");
            }
        }

        fireworkGroupDto.setFireworks(fireworks);
        fireworkGroupDto.setTag(fireworkGroup.getTag());
        fireworkGroupDto.setModel(fireworkGroup.getModel());
        fireworkGroupDto.setAudio(fireworkGroup.getRawAudio().getContent());
        return fireworkGroupDto;
    }
    
    public FireworkGroup ToFireworkGroup() {
        FireworkGroup fireworkGroup = new FireworkGroup();
        List<FireworkBase> fireworks = new ArrayList<>();
        
        for (FireworkBaseDto fireworkBaseDto : Fireworks) {
            
            switch (fireworkBaseDto.getType()) {

                case Normal:
                    FireworkNormalDto fireworkNormalDto = (FireworkNormalDto) fireworkBaseDto;
                    FireworkNormal fireworkNormal = new FireworkNormal();

                    fireworkNormal.setFireworkGroup(fireworkGroup);
                    fireworkNormal.setX(fireworkNormalDto.getX());
                    fireworkNormal.setY(fireworkNormalDto.getY());
                    fireworkNormal.setZ(fireworkNormalDto.getZ());
                    fireworkNormal.setColor(fireworkNormalDto.getFireworkColor());
                    fireworkNormal.setInitialVelocity(fireworkNormalDto.getInitialVelocity());
                    fireworkNormal.setRadius(fireworkNormalDto.getRadius());
                    
                    fireworks.add(fireworkNormal);
                    break;
                    
                case OnlyTrail:
                    FireworkOnlyTrailDto fireworkOnlyTrailDto = (FireworkOnlyTrailDto) fireworkBaseDto;
                    FireworkOnlyTrail fireworkOnlyTrail = new FireworkOnlyTrail();

                    fireworkOnlyTrail.setFireworkGroup(fireworkGroup);
                    fireworkOnlyTrail.setX(fireworkOnlyTrailDto.getX());
                    fireworkOnlyTrail.setY(fireworkOnlyTrailDto.getY());
                    fireworkOnlyTrail.setZ(fireworkOnlyTrailDto.getZ());
                    fireworkOnlyTrail.setLaunchAngel(fireworkOnlyTrailDto.getLaunchAngel());
                    fireworkOnlyTrail.setInitialVelocity(fireworkOnlyTrailDto.getInitialVelocity());
                    fireworkOnlyTrail.setAngularVelocity(fireworkOnlyTrailDto.getAngularVelocity());
                    fireworkOnlyTrail.setLaunchInterval(fireworkOnlyTrailDto.getLaunchInterval());
                    fireworkOnlyTrail.setColor(fireworkOnlyTrailDto.getFireworkColor());

                    fireworks.add(fireworkOnlyTrail);
                    break;
                    
                case Brocade:
                    FireworkBrocadeDto fireworkBrocadeDto = (FireworkBrocadeDto) fireworkBaseDto;
                    FireworkBrocade fireworkBrocade = new FireworkBrocade();

                    fireworkBrocade.setFireworkGroup(fireworkGroup);
                    fireworkBrocade.setX(fireworkBrocadeDto.getX());
                    fireworkBrocade.setY(fireworkBrocadeDto.getY());
                    fireworkBrocade.setZ(fireworkBrocadeDto.getZ());
                    fireworkBrocade.setColor(fireworkBrocadeDto.getFireworkColor());
                    fireworkBrocade.setInitialVelocity(fireworkBrocadeDto.getInitialVelocity());
                    fireworkBrocade.setRadius(fireworkBrocadeDto.getRadius());

                    fireworks.add(fireworkBrocade);
                    break;
                    
                case Crackle:
                    FireworkCrackleDto fireworkCrackleDto = (FireworkCrackleDto) fireworkBaseDto;
                    FireworkCrackle fireworkCrackle = new FireworkCrackle();

                    fireworkCrackle.setFireworkGroup(fireworkGroup);
                    fireworkCrackle.setX(fireworkCrackleDto.getX());
                    fireworkCrackle.setY(fireworkCrackleDto.getY());
                    fireworkCrackle.setZ(fireworkCrackleDto.getZ());
                    fireworkCrackle.setInitialVelocity(fireworkCrackleDto.getInitialVelocity());

                    fireworks.add(fireworkCrackle);
                    break;
                    
                case Mine:
                    FireworkMineDto fireworkMineDto = (FireworkMineDto) fireworkBaseDto;
                    FireworkMine fireworkMine = new FireworkMine();

                    fireworkMine.setFireworkGroup(fireworkGroup);
                    fireworkMine.setX(fireworkMineDto.getX());
                    fireworkMine.setY(fireworkMineDto.getY());
                    fireworkMine.setZ(fireworkMineDto.getZ());
                    fireworkMine.setInitialVelocity(fireworkMineDto.getInitialVelocity());

                    fireworks.add(fireworkMine);
                    break;
                    
                case ThreeLayers:
                    FireworkThreeLayersDto fireworkThreeLayersDto = (FireworkThreeLayersDto) fireworkBaseDto;
                    FireworkThreeLayers fireworkThreeLayers = new FireworkThreeLayers();

                    fireworkThreeLayers.setFireworkGroup(fireworkGroup);
                    fireworkThreeLayers.setX(fireworkThreeLayersDto.getX());
                    fireworkThreeLayers.setY(fireworkThreeLayersDto.getY());
                    fireworkThreeLayers.setZ(fireworkThreeLayersDto.getZ());
                    fireworkThreeLayers.setColorInside(fireworkThreeLayersDto.getFireworkColorInside());
                    fireworkThreeLayers.setColorOutside(fireworkThreeLayersDto.getFireworkColorOutside());
                    fireworkThreeLayers.setInitialVelocity(fireworkThreeLayersDto.getInitialVelocity());
                    fireworkThreeLayers.setRadius(fireworkThreeLayersDto.getRadius());

                    fireworks.add(fireworkThreeLayers);
                    break;
                    
                case Image:
                    FireworkImageDto fireworkImageDto = (FireworkImageDto) fireworkBaseDto;
                    FireworkImage fireworkImage = new FireworkImage();
                    RawImage rawImage = new RawImage();

                    fireworkImage.setFireworkGroup(fireworkGroup);
                    fireworkImage.setX(fireworkImageDto.getX());
                    fireworkImage.setY(fireworkImageDto.getY());
                    fireworkImage.setZ(fireworkImageDto.getZ());
                    fireworkImage.setInitialVelocity(fireworkImageDto.getInitialVelocity());
                    fireworkImage.setDefaultImage(fireworkImageDto.getDefaultImage());
                    fireworkImage.setWidth(fireworkImageDto.getWidth());
                    fireworkImage.setHeight(fireworkImageDto.getHeight());
                    rawImage.setContent(fireworkImageDto.getRawImage());

                    fireworkImage.setRawImage(rawImage);
                    rawImage.setFireworkImage(fireworkImage);
                    fireworks.add(fireworkImage);
                    break;
                    
                default:
                    System.out.println("Unknown firework type.");
            }
        }

        RawAudio rawAudio = new RawAudio();
        rawAudio.setFireworkGroup(fireworkGroup);
        rawAudio.setContent(Audio);
        
        fireworkGroup.setTag(Tag);
        fireworkGroup.setModel(Model);
        fireworkGroup.setFireworkList(fireworks);
        fireworkGroup.setRawAudio(rawAudio);
        return fireworkGroup;
    }
}
