package com.fireworklab.backend.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorValue(value = "OnlyTrail")
public class FireworkOnlyTrail extends FireworkBase {

    @Column(name = "float_1")
    private Double launchAngel;

    @Column(name = "float_2")
    private Double initialVelocity;

    @Column(name = "float_3")
    private Double angularVelocity;

    @Column(name = "float_4")
    private Double launchInterval;

    @Column(name = "str_1")
    @Enumerated(value = EnumType.STRING)
    private FireworkColorType color;
}
