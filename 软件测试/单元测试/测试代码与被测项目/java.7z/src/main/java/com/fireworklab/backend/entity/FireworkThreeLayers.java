package com.fireworklab.backend.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorValue(value = "ThreeLayers")
public class FireworkThreeLayers extends FireworkBase{

    @Column(name = "str_1")
    @Enumerated(value = EnumType.STRING)
    private FireworkColorType colorInside;

    @Column(name = "str_2")
    @Enumerated(value = EnumType.STRING)
    private FireworkColorType colorOutside;

    @Column(name = "float_1")
    private Double radius;

    @Column(name = "float_2")
    private Double initialVelocity;
}
