package com.fireworklab.backend.entity;

public enum FireworkType {
    None, Normal, OnlyTrail, Brocade, Crackle, Mine, ThreeLayers, Image
}
