package com.fireworklab.backend.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "user_message")
public class UserMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    Integer id;

    @Column(name = "message")
    String message;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    QrCodeUser qrCodeUser;
}
