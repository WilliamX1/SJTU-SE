package com.fireworklab.backend.repository;

import com.fireworklab.backend.entity.QrCodeUser;
import com.fireworklab.backend.entity.TagOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TagOrderRepository extends JpaRepository<TagOrder, Integer> {

    Page<TagOrder> findAllByQrCodeUser(QrCodeUser qrCodeUser, Pageable pageable);
}
