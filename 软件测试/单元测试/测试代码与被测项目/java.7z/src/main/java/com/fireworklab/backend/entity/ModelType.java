package com.fireworklab.backend.entity;

public enum ModelType {
    Cake1, CrystallBall, Dog, JapanHouse, JapanRestaurant, StoneHouse
}
