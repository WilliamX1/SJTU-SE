package com.fireworklab.backend.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorValue(value = "Mine")
public class FireworkMine extends FireworkBase{

    @Column(name = "float_1")
    private Double initialVelocity;
}
