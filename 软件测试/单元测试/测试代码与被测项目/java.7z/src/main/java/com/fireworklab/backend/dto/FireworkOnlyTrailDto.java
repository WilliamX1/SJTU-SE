package com.fireworklab.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.FireworkColorType;
import com.fireworklab.backend.entity.FireworkType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FireworkOnlyTrailDto extends FireworkBaseDto{

    @JsonProperty("LaunchAngel")
    private Double LaunchAngel;

    @JsonProperty("InitialVelocity")
    private Double InitialVelocity;

    @JsonProperty("AngularVelocity")
    private Double AngularVelocity;

    @JsonProperty("LaunchInterval")
    private Double LaunchInterval;

    @JsonProperty("FireworkColor")
    private FireworkColorType FireworkColor;

    public FireworkOnlyTrailDto(FireworkType type, Double x, Double y, Double z, Double launchAngel, Double initialVelocity, Double angularVelocity, Double launchInterval, FireworkColorType fireworkColor) {
        super(type, x, y, z);
        LaunchAngel = launchAngel;
        InitialVelocity = initialVelocity;
        AngularVelocity = angularVelocity;
        LaunchInterval = launchInterval;
        FireworkColor = fireworkColor;
    }
}
