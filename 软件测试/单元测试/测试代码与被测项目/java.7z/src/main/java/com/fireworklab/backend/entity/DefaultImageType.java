package com.fireworklab.backend.entity;

public enum DefaultImageType {
    Bear1, Bear2, Bird1, Bird2, BlueButterfly, Boy1, Boy2, Butterfly2, Butterfly3,
    Chicken, Fox, Girl1, GoodLuck, ILOVEYOU, HappyBirthday, Monkey, PearlGirl, RedButterfly, SafeAndSound,
    SnowFlake, StaryNight1, StaryNight2, SunFlower, Tiger, VanGogh, None
}
