package com.fireworklab.backend.repository;

import com.fireworklab.backend.entity.FireworkGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FireworkGroupRepository extends JpaRepository<FireworkGroup, Long> {

    FireworkGroup findByTag(Long tag);
}
