package com.fireworklab.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.FireworkType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FireworkBaseDto {

    @JsonProperty("Type")
    private FireworkType Type;

    @JsonProperty("X")
    private Double X;

    @JsonProperty("Y")
    private Double Y;

    @JsonProperty("Z")
    private Double Z;

    public FireworkBaseDto(FireworkType type, Double x, Double y, Double z) {
        Type = type;
        X = x;
        Y = y;
        Z = z;
    }
}
