package com.fireworklab.backend.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "tag")
public class Tag {

    @Id
    @Column(name = "id")
    Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    TagOrder tagOrder;
}
