package com.fireworklab.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.DefaultImageType;
import com.fireworklab.backend.entity.FireworkType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FireworkImageDto extends FireworkBaseDto{

    @JsonProperty("InitialVelocity")
    private Double InitialVelocity;

    @JsonProperty("Width")
    private Integer Width;

    @JsonProperty("Height")
    private Integer Height;

    @JsonProperty("RawImage")
    private byte[] RawImage;

    @JsonProperty("DefaultImage")
    private DefaultImageType DefaultImage;

    public FireworkImageDto(FireworkType type, Double x, Double y, Double z, Double initialVelocity, Integer width, Integer height, byte[] rawImage, DefaultImageType defaultImage) {
        super(type, x, y, z);
        InitialVelocity = initialVelocity;
        Width = width;
        Height = height;
        RawImage = rawImage;
        DefaultImage = defaultImage;
    }
}
