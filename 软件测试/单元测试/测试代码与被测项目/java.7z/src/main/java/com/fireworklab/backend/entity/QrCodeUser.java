package com.fireworklab.backend.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "qrcode_user")
public class QrCodeUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    Integer id;

    @Column(name = "username")
    String username;

    @Column(name = "password")
    String password;

    @Column(name = "user_type")
    @Enumerated()
    QrCodeUserType userType;

    @OneToMany(mappedBy = "qrCodeUser", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    List<TagOrder> tagOrderList;

    @OneToOne(mappedBy = "qrCodeUser", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    UserMessage userMessage;
}
