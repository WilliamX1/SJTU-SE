package com.fireworklab.backend.entity;

public enum FireworkColorType {

    Carmine,    // Li
    Yellow,     // Na
    Lilac,      // K
    BrickRed,   // Ca
    Crimson,    // Sr
    PaleGreen,  // Ba
    Green,      // Cu
}
